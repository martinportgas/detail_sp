<?php 
$directory = "Sample";

$conn =new mysqli('localhost', 'root', '' , 'detailsp');
?>